package com.jetbrains.backendwoolu;

import java.io.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.json.JSONObject;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    public void init() {
        // Inizializzazione del servlet
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("ciao");
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();


        BufferedReader reader = request.getReader();
        StringBuilder jsonBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonBuilder.append(line);
        }

        // Parla JSON
        JSONObject jsonObject = new JSONObject(jsonBuilder.toString());
        String username = jsonObject.getString("username");
        String password = jsonObject.getString("password");


        JSONObject jsonResponse = new JSONObject();
        if ("user".equals(username) && "password".equals(password)) {
            jsonResponse.put("message", "Login successful for user: " + username);
        } else {
            jsonResponse.put("message", "Login failed");
        }


        out.println(jsonResponse.toString());
    }

    public void destroy() {

    }
}
